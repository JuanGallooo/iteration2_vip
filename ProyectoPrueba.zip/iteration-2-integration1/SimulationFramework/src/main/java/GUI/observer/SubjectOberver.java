package GUI.observer;

public interface SubjectOberver {

	void subscribe(Observer observer);
	
}
