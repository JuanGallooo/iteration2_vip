package GUI.Marker;

public class ExTest {

	public static void main(String[] args) {
		 MarkerInfo info =new MarkerInfo();
	}

}
