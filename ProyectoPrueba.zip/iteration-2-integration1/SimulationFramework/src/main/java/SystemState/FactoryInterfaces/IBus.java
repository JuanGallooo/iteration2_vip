package SystemState.FactoryInterfaces;

public interface IBus {
}