package SystemState.FactoryInterfaces;

public interface ITrip {
}