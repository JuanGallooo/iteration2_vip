package SystemState.FactoryInterfaces;

public interface ILineStop {

}
