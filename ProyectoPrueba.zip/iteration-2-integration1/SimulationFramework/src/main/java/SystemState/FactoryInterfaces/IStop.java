package SystemState.FactoryInterfaces;

public interface IStop {
}