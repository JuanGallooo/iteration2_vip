package SystemState.FactoryInterfaces;

public interface IArc {
}