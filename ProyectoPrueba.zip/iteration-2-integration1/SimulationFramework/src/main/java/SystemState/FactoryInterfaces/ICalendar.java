package SystemState.FactoryInterfaces;

public interface ICalendar {
}