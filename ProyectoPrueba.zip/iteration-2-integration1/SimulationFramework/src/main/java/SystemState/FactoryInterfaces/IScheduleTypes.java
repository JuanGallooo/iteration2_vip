package SystemState.FactoryInterfaces;

public interface IScheduleTypes {
}