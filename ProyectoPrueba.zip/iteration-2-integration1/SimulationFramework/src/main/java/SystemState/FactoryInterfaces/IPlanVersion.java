package SystemState.FactoryInterfaces;

public interface IPlanVersion {
}