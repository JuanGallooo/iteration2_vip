package com.vip.simulation.simulation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimulationApplicationTests {

	@Test
	void contextLoads() {
	}

}
